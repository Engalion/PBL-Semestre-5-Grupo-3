gcc png2bin.c -lpng -o png2bin.exe

