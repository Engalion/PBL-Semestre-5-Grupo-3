Added the freeware bitmap font editor Fony 1.4.7 (Windows exe) to this repository.
The original web site is not available any more.

Issue: https://github.com/olikraus/u8g2/issues/558

Update: The orginal site is online again at http://hukka.ncn.fi/?fony


