gcc png2bdf.c -lpng -o png2bdf.exe

