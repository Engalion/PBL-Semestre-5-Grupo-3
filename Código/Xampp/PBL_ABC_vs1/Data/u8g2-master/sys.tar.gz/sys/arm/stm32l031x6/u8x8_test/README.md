![https://https://raw.githubusercontent.com/olikraus/u8g2/refs/heads/master/sys/arm/stm32l031x6/u8x8_test/stm32l031.jpg](https://raw.githubusercontent.com/olikraus/u8g2/refs/heads/master/sys/arm/stm32l031x6/u8x8_test/stm32l031.jpg)

