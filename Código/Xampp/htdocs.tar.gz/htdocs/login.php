<?php
// Inclui ligação à base de dados
include "db.php";

// Inclui funções de autenticação e sessão
include "auth.php";

// Se o utilizador já estiver autenticado, redireciona para a página principal
if (is_logged_in()) {
    header("Location: index.php");
    exit;
}

// Variável para mensagens de erro
$erro = "";

// Processa o formulário apenas quando enviado via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Obtém e sanitiza os dados enviados
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validação básica dos campos
    if ($username === '' || $password === '') {
        $erro = "Preenche utilizador e password.";
    } else {

        // Prepara a query para evitar SQL Injection
        $stmt = $conn->prepare(
            "SELECT id, username, password_hash, role 
             FROM users 
             WHERE username = ? 
             LIMIT 1"
        );
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        // Verifica se o utilizador existe
        if ($res && $res->num_rows === 1) {
            $user = $res->fetch_assoc();

            // Confirma a password usando password_verify
            if (password_verify($password, $user['password_hash'])) {

                // Guarda apenas os dados essenciais na sessão
                $_SESSION['user'] = [
                    "id"       => (int)$user["id"],
                    "username" => $user["username"],
                    "role"     => $user["role"]
                ];

                // Redireciona após login bem-sucedido
                header("Location: index.php");
                exit;
            }
        }

        // Mensagem genérica para não revelar se o utilizador existe
        $erro = "Login inválido.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">

<!-- Título da página -->
<title>SecureRoom — Login</title>

<!-- CSS principal -->
<link rel="stylesheet" href="style.css">

<style>
/* Container central do formulário de login */
.loginWrap{max-width:420px;margin:60px auto;}

/* Cartão com efeito glassmorphism */
.loginCard{
  background: rgba(255,255,255,0.10);
  border: 1px solid rgba(255,255,255,0.14);
  border-radius: 18px;
  padding: 22px;
  backdrop-filter: blur(18px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.28);
}

.loginCard h1{margin:0 0 14px;font-size:28px;text-align:center;}

/* Campos do formulário */
.field{display:flex;flex-direction:column;gap:8px;margin:12px 0;}
.field input{
  padding:12px 14px;
  border-radius:12px;
  border:1px solid rgba(255,255,255,0.14);
  background: rgba(0,0,0,0.25);
  color:#fff;
  font-size:16px;
}

/* Caixa de erro */
.err{
  background: rgba(255,77,109,0.14);
  border: 1px solid rgba(255,77,109,0.35);
  padding: 10px 12px;
  border-radius: 12px;
  font-weight:700;
  margin-bottom: 12px;
}

/* Botão de submissão */
.loginCard button{
  width:100%;
  padding:12px 14px;
  border-radius:12px;
  border:none;
  background: linear-gradient(45deg,#00c6ff,#0072ff);
  color:#fff;
  font-weight:800;
  font-size:16px;
  cursor:pointer;
  margin-top: 8px;
}

/* Texto informativo inferior */
.small{
  opacity:.8;
  font-size:12px;
  text-align:center;
  margin-top:10px;
}
</style>
</head>
<body>

<!-- Estrutura visual do formulário -->
<div class="loginWrap">
  <div class="loginCard">
    <h1>🔐 Secure Room</h1>

    <!-- Mostra erro, se existir -->
    <?php if ($erro): ?>
      <div class="err"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <!-- Formulário de login -->
    <form method="POST">

      <div class="field">
        <label>Utilizador</label>
        <input name="username" autocomplete="username" required>
      </div>

      <div class="field">
        <label>Password</label>
        <input name="password" type="password" autocomplete="current-password" required>
      </div>

      <button type="submit">Entrar</button>
    </form>

    <div class="small">Acesso restrito • SecureRoom</div>
  </div>
</div>

</body>
</html> 