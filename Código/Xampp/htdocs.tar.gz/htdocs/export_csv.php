<?php
include "auth.php";
require_admin();
include "db.php";

/*
  Exporta CSV dos sensores:
  - Admin pode exportar temperatura/humidade/movimento
  - tipo=temperatura|humidade|movimento|todos
  - inicio=YYYY-MM-DD
  - fim=YYYY-MM-DD
*/

$tipo   = $_GET['tipo'] ?? 'todos';
$inicio = $_GET['inicio'] ?? '';
$fim    = $_GET['fim'] ?? '';

$allowed = ['todos','temperatura','humidade','movimento'];
if (!in_array($tipo, $allowed, true)) {
  $tipo = 'todos';
}

$where = [];
if ($tipo !== 'todos') {
  $where[] = "s.tipo='" . $conn->real_escape_string($tipo) . "'";
}
if ($inicio) {
  $where[] = "s.data_hora >= '" . $conn->real_escape_string($inicio) . " 00:00:00'";
}
if ($fim) {
  $where[] = "s.data_hora <= '" . $conn->real_escape_string($fim) . " 23:59:59'";
}

$whereSQL = $where ? ("WHERE " . implode(" AND ", $where)) : "";

/* Query simples — sem estado do movimento */
$sql = "
SELECT
  s.id,
  s.tipo,
  s.valor,
  s.data_hora
FROM sensores s
$whereSQL
ORDER BY s.data_hora ASC
";

$res = $conn->query($sql);

$filename = "secureRoom_export_" . date("Y-m-d_H-i-s") . ".csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');

$out = fopen('php://output', 'w');

/* Cabeçalho */
fputcsv($out, ['id','tipo','valor','data_hora']);

if ($res) {
  while ($r = $res->fetch_assoc()) {
    fputcsv($out, [
      $r['id'],
      $r['tipo'],
      $r['valor'],
      $r['data_hora']
    ]);
  }
}

fclose($out);
exit;