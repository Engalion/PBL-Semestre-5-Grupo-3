<?php
// Inclui o sistema de autenticação e garante acesso à sessão
include "auth.php";

// Destroi a sessão atual ou seja o logout do utilizador
session_destroy();

// Redireciona o utilizador para a página de login
header("Location: login.php");
exit;
