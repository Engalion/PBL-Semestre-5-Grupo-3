<?php
include "db.php";
include "auth.php";
require_admin();

$msg = "";
$err = "";

// DEFINIR quem é o "admin principal" que não pode perder admin
$superAdminId = 1;

// user logado
$currentUserId = (int) (current_user()['id'] ?? 0);

/* =========================
          CRIAR USER
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_user') {
    $username = trim($_POST['username'] ?? '');
    $role = $_POST['role'] ?? 'user';
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $err = "Username e password são obrigatórios.";
    } else {
        // valida role
        if (!in_array($role, ['user', 'admin'], true)) $role = 'user';

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hash, $role);

        if ($stmt->execute()) $msg = "Utilizador criado com sucesso.";
        else $err = "Erro ao criar: " . $conn->error;
    }
}

/* =========================
        RESET PASSWORD
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset_pass') {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $newpass = $_POST['newpass'] ?? '';

    if ($user_id <= 0 || $newpass === '') {
        $err = "Dados inválidos para reset.";
    }
    // 🔒 BLOQUEIO: ninguém pode mudar a password do admin principal, exceto ele próprio
    elseif ($user_id === $superAdminId && $currentUserId !== $superAdminId) {
        $err = "Só o Admin principal pode alterar a sua própria password.";
    }
    else {
        $hash = password_hash($newpass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password_hash=? WHERE id=?");
        $stmt->bind_param("si", $hash, $user_id);

        if ($stmt->execute()) $msg = "Password atualizada.";
        else $err = "Erro: " . $conn->error;
    }
}

/* =================================
      ALTERAR ROLE dar/tirar admin
   ================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'set_role') {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $newRole = $_POST['newRole'] ?? '';

    if ($user_id <= 0 || !in_array($newRole, ['user', 'admin'], true)) {
        $err = "Pedido inválido para alterar role.";
    } else {
        // Bloqueio: ninguém pode tirar admin ao admin principal
        if ($user_id === $superAdminId && $newRole !== 'admin') {
            $err = "Não é permitido remover o role admin do Admin principal (ID $superAdminId).";
        } else {
            $stmt = $conn->prepare("UPDATE users SET role=? WHERE id=?");
            $stmt->bind_param("si", $newRole, $user_id);
            if ($stmt->execute()) $msg = "Role atualizado com sucesso.";
            else $err = "Erro ao atualizar role: " . $conn->error;
        }
    }
}

$users = $conn->query("SELECT id, username, role, created_at FROM users ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SecureRoom — Admin Users</title>
<link rel="stylesheet" href="style.css">
<style>
.adminWrap{max-width:1150px;margin:0 auto;}
.adminHeader{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;}
.adminHeader a{color:#fff;text-decoration:none;opacity:.9;}
.panel{
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 18px;
  padding: 16px;
  backdrop-filter: blur(18px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.25);
  margin-bottom: 14px;
}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
.row input,.row select{
  padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,0.14);
  background:rgba(0,0,0,0.22);color:#fff;
}
.row button{
  padding:10px 12px;border-radius:12px;border:none;
  background:linear-gradient(45deg,#00c6ff,#0072ff);color:#fff;font-weight:800;cursor:pointer;
}
.notice{padding:10px 12px;border-radius:12px;margin-bottom:12px;font-weight:800;}
.ok{background:rgba(0,247,255,0.12);border:1px solid rgba(0,247,255,0.28);}
.bad{background:rgba(255,77,109,0.12);border:1px solid rgba(255,77,109,0.28);}
.smallHint{opacity:.85;font-size:13px;margin-top:6px;}
.lockTag{display:inline-block;padding:4px 10px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);font-size:12px;}
</style>
</head>
<body>
<div class="adminWrap glass">
  <div class="adminHeader">
    <h1>Admin — Utilizadores</h1>
    <div>
      <a href="index.php">← Voltar ao dashboard</a> ·
      <a href="admin_cards.php">Gerir RFID</a> ·
      <a href="logout.php">Sair</a>
    </div>
  </div>

  <?php if ($msg): ?><div class="notice ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="notice bad"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="panel">
    <h2>Criar utilizador</h2>
    <form method="POST" class="row">
      <input type="hidden" name="action" value="create_user">
      <input name="username" placeholder="username" required>
      <input name="password" placeholder="password" required>
      <select name="role">
        <option value="user">user</option>
        <option value="admin">admin</option>
      </select>
      <button type="submit">Criar</button>
    </form>
    <div class="smallHint">Nota: o Admin principal (ID <?= (int)$superAdminId ?>) não pode perder permissões de admin, e só ele pode alterar a sua password.</div>
  </div>

  <div class="panel">
    <h2>Lista de utilizadores</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Username</th><th>Role</th><th>Criado</th>
          <th>Alterar role</th>
          <th>Reset password</th>
        </tr>
      </thead>
      <tbody>
      <?php while($u = $users->fetch_assoc()): ?>
        <?php
          $uid = (int)$u['id'];
          $isSuperAdmin = ($uid === $superAdminId);

          // Role: super admin "não mexe"
          $canChangeRole = !$isSuperAdmin;

          // Password: só o próprio super admin pode mexer na password dele
          $canResetPassword = !($isSuperAdmin && $currentUserId !== $superAdminId);
        ?>
        <tr>
          <td><?= $uid ?></td>
          <td>
            <?= htmlspecialchars($u['username']) ?>
            <?php if ($isSuperAdmin): ?> <span class="lockTag">Admin principal</span><?php endif; ?>
          </td>
          <td><?= htmlspecialchars($u['role']) ?></td>
          <td><?= htmlspecialchars($u['created_at']) ?></td>

          <!-- Alterar role -->
          <td>
            <form method="POST" class="row" style="justify-content:center;">
              <input type="hidden" name="action" value="set_role">
              <input type="hidden" name="user_id" value="<?= $uid ?>">
              <select name="newRole" <?= !$canChangeRole ? 'disabled' : '' ?>>
                <option value="user"  <?= ($u['role']==='user'?'selected':'') ?>>user</option>
                <option value="admin" <?= ($u['role']==='admin'?'selected':'') ?>>admin</option>
              </select>
              <button type="submit" <?= !$canChangeRole ? 'disabled style="opacity:.5;cursor:not-allowed;"' : '' ?>>
                Guardar
              </button>
              <?php if ($isSuperAdmin): ?>
                <span class="lockTag">Protegido</span>
              <?php endif; ?>
            </form>
          </td>

          <!-- Reset pass -->
          <td>
            <form method="POST" class="row" style="justify-content:center;">
              <input type="hidden" name="action" value="reset_pass">
              <input type="hidden" name="user_id" value="<?= $uid ?>">

              <input
                name="newpass"
                placeholder="nova password"
                required
                <?= !$canResetPassword ? 'disabled' : '' ?>
              >

              <button
                type="submit"
                <?= !$canResetPassword ? 'disabled style="opacity:.5;cursor:not-allowed;"' : '' ?>
              >
                Atualizar
              </button>

              <?php if ($isSuperAdmin && !$canResetPassword): ?>
                <span class="lockTag">Protegido</span>
              <?php endif; ?>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>

</div>
</body>
</html>