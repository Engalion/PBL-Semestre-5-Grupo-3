<?php
require_once __DIR__ . "/auth.php";
require_login();
if (!is_admin()) { header("Location: index.php"); exit; }
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>SecureRoom • Forecast</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="glass">

  <div class="topbar">
    <div class="topLeft"><h1>Forecast</h1></div>

    <div class="topRight">
      <a class="chartsBtn" href="index.php">Voltar</a>
      <a class="logoutBtn" href="logout.php">Sair</a>
    </div>
  </div>

  <h2>Temperatura • Próximos 60 minutos</h2>
  <canvas id="c60"></canvas>

  <h2 style="margin-top:22px;">Temperatura • Próximos 180 minutos</h2>
  <canvas id="c180"></canvas>

</div>

<script>
async function loadForecast(h) {
  const res = await fetch(`api/forecast_temp.php?h=${h}&n=120`, { cache: 'no-store' });
  return await res.json();
}

function parseDT(s) {
  // "YYYY-mm-dd HH:MM:SS" -> Date (local)
  // Nota: new Date("YYYY-mm-dd HH:MM:SS") nem sempre é consistente.
  // Faz parse manual.
  const Y = +s.slice(0,4);
  const M = +s.slice(5,7) - 1;
  const D = +s.slice(8,10);
  const h = +s.slice(11,13);
  const m = +s.slice(14,16);
  const sec = +s.slice(17,19);
  return new Date(Y, M, D, h, m, sec);
}

function fmtHM(s) {
  return s.slice(11,16); // HH:MM
}
function fmtDM(s) {
  return s.slice(8,10) + "/" + s.slice(5,7); // dd/mm
}

/* Plugin: linha vertical a separar histórico vs forecast + sombreado no forecast */
function boundaryPlugin(histLen) {
  return {
    id: 'boundaryLine',
    afterDraw(chart) {
      const { ctx, chartArea, scales } = chart;
      if (!chartArea) return;

      // boundary at histLen-1 (último ponto do histórico)
      const xScale = scales.x;
      const boundaryIndex = Math.max(0, histLen - 1);
      const x = xScale.getPixelForValue(boundaryIndex);

      ctx.save();

      // sombreado na zona forecast (da boundary até ao fim)
      ctx.fillStyle = 'rgba(255,196,0,0.05)';
      ctx.fillRect(x, chartArea.top, chartArea.right - x, chartArea.bottom - chartArea.top);

      // linha vertical
      ctx.strokeStyle = 'rgba(255,255,255,0.20)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, chartArea.top);
      ctx.lineTo(x, chartArea.bottom);
      ctx.stroke();

      ctx.restore();
    }
  };
}

/* Melhor eixo X:
   - mostra HH:MM
   - se mudar de dia, mostra "dd/mm HH:MM"
*/
function fmtHM(s){ return s.slice(11,16); }
function fmtDM(s){ return s.slice(8,10)+"/"+s.slice(5,7); }

function tickLabelSmart(labelsAll, i) {
  if (i <= 0) return fmtDM(labelsAll[i]) + " " + fmtHM(labelsAll[i]);

  const prevDay = labelsAll[i-1].slice(0,10);
  const curDay  = labelsAll[i].slice(0,10);

  if (prevDay !== curDay) return fmtDM(labelsAll[i]) + " " + fmtHM(labelsAll[i]);
  return fmtHM(labelsAll[i]);
}


/* Banda IC 95% como “faixa” (1 item na legenda) */
function makeChart(canvasId, payload) {
  const ctx = document.getElementById(canvasId);

  const labelsAll = [...payload.history.labels, ...payload.forecast.labels];
  const histLen   = payload.history.data.length;
  const fcLen     = payload.forecast.mean.length;

  // alinhamentos
  const histAligned  = payload.history.data.concat(new Array(fcLen).fill(null));
  const fcAligned    = new Array(histLen).fill(null).concat(payload.forecast.mean);

  const lowerAligned = new Array(histLen).fill(null).concat(payload.forecast.lower);
  const upperAligned = new Array(histLen).fill(null).concat(payload.forecast.upper);

  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: labelsAll,
      datasets: [
        // Histórico = COM PONTOS
        {
          label: "Histórico",
          data: histAligned,
          showLine: false,
          pointRadius: 3,
          pointHoverRadius: 6,
          pointBackgroundColor: '#00f7ff',
          pointBorderColor: '#00f7ff',
          pointBorderWidth: 0,
          pointStyle: 'circle',
          pointRotation: 0
        },

        // IC 95% -> 2 datasets: lower + upper
        {
          label: "_IC_LOWER_",
          data: lowerAligned,
          borderColor: 'rgba(0,0,0,0)',
          backgroundColor: 'rgba(0,0,0,0)',
          pointRadius: 0
        },
        {
          label: "IC 95%",
          data: upperAligned,
          borderColor: 'rgba(0,0,0,0)',
          backgroundColor: 'rgba(255,196,0,0.16)',
          pointRadius: 0,
          fill: '-1'
        },

        // Forecast = linha
        {
          label: "Forecast",
          data: fcAligned,
          borderColor: '#ffc400',
          backgroundColor: 'rgba(255,196,0,0.08)',
          borderWidth: 4,
          pointRadius: 0,
          tension: 0.35,
          fill: false,
          pointStyle: 'line'
        }
      ]
    },
    options: {
      plugins: {
        legend: {
          labels: {
            color: '#fff',
            usePointStyle: true,
            filter: (item, data) => data.datasets[item.datasetIndex].label !== "_IC_LOWER_"
          }
        },

        tooltip: {
          callbacks: {
            title: (items) => {
              const idx = items?.[0]?.dataIndex ?? 0;
              return labelsAll[idx];
            },
            label: (item) => {
              const v = item.raw;
              if (v === null || typeof v === "undefined") return "";
              return `${item.dataset.label}: ${Number(v).toFixed(2)} ºC`;
            }
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: '#fff',
            maxTicksLimit: 10,
            maxRotation: 0,
            minRotation: 0,
            callback: (value, index) => tickLabelSmart(labelsAll, index)
          },
          grid: { color: 'rgba(255,255,255,0.08)' }
        },

        y: {
          ticks: { color: '#fff' },
          grid: { color: 'rgba(255,255,255,0.08)' }
        }
      }
    },
    plugins: [boundaryPlugin(histLen)]
  });
}

(async () => {
  const d60 = await loadForecast(60);
  if (d60.ok) makeChart("c60", d60);

  const d180 = await loadForecast(180);
  if (d180.ok) makeChart("c180", d180);
})();
</script>
</body>
</html>