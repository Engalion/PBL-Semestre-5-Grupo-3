<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../auth.php";
require_login();

$role = current_user()['role'] ?? 'user';
$isAdmin = ($role === 'admin');

$tipo = $_GET['tipo'] ?? 'todos';
$inicio = $_GET['inicio'] ?? '';
$fim = $_GET['fim'] ?? '';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
$chartLimit = isset($_GET['chartLimit']) ? (int)$_GET['chartLimit'] : 40;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, $page);

$allowedTipos = $isAdmin
  ? ['todos','temperatura','humidade','movimento']
  : ['temperatura','humidade'];

if (!in_array($tipo, $allowedTipos, true)) {
  $tipo = $isAdmin ? 'todos' : 'temperatura';
}

$limit = max(1, min($limit, 200));
$chartLimit = max(5, min($chartLimit, 200));

$offset = ($page - 1) * $limit;

$where = [];

/* User normal: SEMPRE últimas 24h tabela + gráfico */
if (!$isAdmin) {
  $where[] = "s.data_hora >= (NOW() - INTERVAL 24 HOUR)";
  $where[] = "s.tipo IN ('temperatura','humidade')";
}

/* Filtro por tipo */
if ($tipo !== 'todos') {
  $where[] = "s.tipo='" . $conn->real_escape_string($tipo) . "'";
}

/* Datas: só admin */
if ($isAdmin) {
  if ($inicio) $where[] = "s.data_hora >= '" . $conn->real_escape_string($inicio) . " 00:00:00'";
  if ($fim) $where[] = "s.data_hora <= '" . $conn->real_escape_string($fim) . " 23:59:59'";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

$total = 0;
$countRes = $conn->query("SELECT COUNT(*) AS total FROM sensores s $whereSQL");
if ($countRes && $countRes->num_rows) {
  $total = (int)$countRes->fetch_assoc()['total'];
}
$totalPages = ($limit > 0) ? (int)ceil($total / $limit) : 1;
$hasPrev = ($page > 1);
$hasNext = ($offset + $limit < $total);

/* ------------------------------
   TABELA com o estado_no_momento
   ------------------------------ */
$sql = "
SELECT
  s.*,
  CASE
    WHEN s.tipo = 'movimento' THEN (
      SELECT a.estado
      FROM acessos a
      WHERE a.data_hora <= s.data_hora
      ORDER BY a.data_hora DESC
      LIMIT 1
    )
    ELSE NULL
  END AS estado_no_momento
FROM sensores s
$whereSQL
ORDER BY s.data_hora DESC
LIMIT $limit OFFSET $offset
";
$res = $conn->query($sql);

$rows = [];
if ($res) {
  while ($r = $res->fetch_assoc()) {
    $display = $r['valor'];
    $badge = "neutral";

    if ($r['tipo'] === 'movimento') {
      $estado = $r['estado_no_momento'];
      if ($estado === 'entrada') {
        $display = "Autorizado ✅";
        $badge = "ok";
      } elseif ($estado === null) {
        $display = "Desconhecido ❔";
        $badge = "warn";
      } else {
        $display = "Não autorizado 🚨";
        $badge = "bad";
      }
    } else {
      if ($r['tipo'] === 'temperatura') $display .= " ºC";
      if ($r['tipo'] === 'humidade') $display .= " %";
    }

    $rows[] = [
      "id" => (int)$r["id"],
      "tipo" => $r["tipo"],
      "valorDisplay" => $display,
      "badge" => $badge,
      "data_hora" => $r["data_hora"],
    ];
  }
}

/* --------------------------------------------------------------------
    Apresenta os últimos valores — Só apresenta as ultimas 24h no user
   -------------------------------------------------------------------- */
function lastValue($conn, $tipo, $isAdmin) {
  $tipoEsc = $conn->real_escape_string($tipo);
  $sql = "SELECT valor, data_hora FROM sensores WHERE tipo='$tipoEsc'";
  if (!$isAdmin) $sql .= " AND data_hora >= (NOW() - INTERVAL 24 HOUR)";
  $sql .= " ORDER BY data_hora DESC LIMIT 1";
  $q = $conn->query($sql);
  if ($q && $q->num_rows) return $q->fetch_assoc();
  return null;
}

$lastTemp = lastValue($conn, "temperatura", $isAdmin);
$lastHum  = lastValue($conn, "humidade", $isAdmin);

/* Movimento/RFID: user normal neutro */
$movStatus = ["label" => "Sem dados", "badge" => "neutral", "data_hora" => null];
$rfidCard  = ["label" => "Sem acessos", "badge" => "neutral", "uid" => null, "data_hora" => null];

if ($isAdmin) {
  $lastMov = $conn->query("
    SELECT
      s.data_hora,
      CASE
        WHEN (
          SELECT a.estado
          FROM acessos a
          WHERE a.data_hora <= s.data_hora
          ORDER BY a.data_hora DESC
          LIMIT 1
        ) = 'entrada' THEN 1
        WHEN (
          SELECT a.estado
          FROM acessos a
          WHERE a.data_hora <= s.data_hora
          ORDER BY a.data_hora DESC
          LIMIT 1
        ) IS NULL THEN -1
        ELSE 0
      END AS autorizado
    FROM sensores s
    WHERE s.tipo='movimento'
    ORDER BY s.data_hora DESC
    LIMIT 1
  ");

  if ($lastMov && $lastMov->num_rows) {
    $m = $lastMov->fetch_assoc();
    if ((int)$m["autorizado"] === 1) $movStatus = ["label" => "Autorizado ✅", "badge" => "ok", "data_hora" => $m["data_hora"]];
    elseif ((int)$m["autorizado"] === 0) $movStatus = ["label" => "Não autorizado 🚨", "badge" => "bad", "data_hora" => $m["data_hora"]];
    else $movStatus = ["label" => "Desconhecido ❔", "badge" => "warn", "data_hora" => $m["data_hora"]];
  }

  $rfid = $conn->query("SELECT estado, id_usuario, data_hora FROM acessos ORDER BY data_hora DESC LIMIT 1");
  if ($rfid && $rfid->num_rows) {
    $a = $rfid->fetch_assoc();
    $estado = $a["estado"];
    if ($estado === "entrada") $rfidCard = ["label"=>"Desbloqueado (entrada)", "badge"=>"ok", "uid"=>$a["id_usuario"], "data_hora"=>$a["data_hora"]];
    elseif ($estado === "saida") $rfidCard = ["label"=>"Bloqueado (saída)", "badge"=>"neutral", "uid"=>$a["id_usuario"], "data_hora"=>$a["data_hora"]];
    elseif ($estado === "nao_autorizado") $rfidCard = ["label"=>"RFID não autorizado", "badge"=>"bad", "uid"=>$a["id_usuario"], "data_hora"=>$a["data_hora"]];
    else $rfidCard = ["label"=>$estado, "badge"=>"warn", "uid"=>$a["id_usuario"], "data_hora"=>$a["data_hora"]];
  }
}

/* -------------------------
      ALERTAS Temp + hum %
   ------------------------- */
$alerts = [];

if ($lastTemp && isset($lastTemp["valor"])) {
  $t = (float)$lastTemp["valor"];
  if ($t > 22) {
    $alerts[] = "🔥 ALERTA: Temperatura Alta (" . $t . " ºC)";
  }
}

if ($lastHum && isset($lastHum["valor"])) {
  $h = (float)$lastHum["valor"];
  if ($h > 60) {
    $alerts[] = "💧 ALERTA: Humidade Alta (" . $h . " %)";
  }
}

/* -------------------------
            GRÁFICO 
   ------------------------- */
$chart = [
  "type" => ($tipo === "todos") ? "temperatura" : $tipo,
  "labels" => [],
  "series" => []
];

$chartType = $chart["type"];

if ($chartType === "temperatura" || $chartType === "humidade") {
  $chartTypeEsc = $conn->real_escape_string($chartType);

  $qSql = "
    SELECT data_hora, valor
    FROM sensores
    WHERE tipo='$chartTypeEsc'
  ";
  if (!$isAdmin) $qSql .= " AND data_hora >= (NOW() - INTERVAL 24 HOUR)";
  $qSql .= " ORDER BY data_hora DESC LIMIT $chartLimit";

  $q = $conn->query($qSql);

  $labels = [];
  $data = [];
  if ($q) {
    while ($x = $q->fetch_assoc()) {
      $labels[] = $x["data_hora"];
      $data[] = (float)$x["valor"];
    }
  }

  $chart["labels"] = array_reverse($labels);
  $chart["series"] = [[
    "label" => ($chartType === "temperatura") ? "Temperatura ºC" : "Humidade %",
    "data" => array_reverse($data)
  ]];
}

if ($chartType === "movimento") {
  $chart["labels"] = [];
  $chart["series"] = [];

  if ($isAdmin) {
    $q = $conn->query("
      SELECT
        s.data_hora,
        (
          SELECT a.estado
          FROM acessos a
          WHERE a.data_hora <= s.data_hora
          ORDER BY a.data_hora DESC
          LIMIT 1
        ) AS estado_no_momento
      FROM sensores s
      WHERE s.tipo='movimento'
      ORDER BY s.data_hora DESC
      LIMIT $chartLimit
    ");

    $labels = [];
    $auth = [];
    $noauth = [];

    if ($q) {
      while ($x = $q->fetch_assoc()) {
        $labels[] = $x["data_hora"];
        $estado = $x["estado_no_momento"];
        if ($estado === "entrada") {
          $auth[] = 1; $noauth[] = null;
        } elseif ($estado === null) {
          $auth[] = null; $noauth[] = null;
        } else {
          $auth[] = null; $noauth[] = 1;
        }
      }
    }

    $chart["labels"] = array_reverse($labels);
    $chart["series"] = [
      ["label"=>"Movimento autorizado", "data"=>array_reverse($auth)],
      ["label"=>"Movimento NÃO autorizado", "data"=>array_reverse($noauth)]
    ];
  }
}

echo json_encode([
  "ok" => true,
  "filters" => ["tipo"=>$tipo,"inicio"=>$inicio,"fim"=>$fim],
  "pagination" => [
    "page" => $page,
    "limit" => $limit,
    "total" => $total,
    "totalPages" => max(1, $totalPages),
    "hasPrev" => $hasPrev,
    "hasNext" => $hasNext
  ],
  "cards" => [
    "temp" => $lastTemp ? ["valor"=>$lastTemp["valor"], "data_hora"=>$lastTemp["data_hora"]] : null,
    "hum"  => $lastHum  ? ["valor"=>$lastHum["valor"],  "data_hora"=>$lastHum["data_hora"]] : null,
    "mov"  => $movStatus,
    "rfid" => $rfidCard
  ],
  "alerts" => $alerts,
  "rows" => $rows,
  "chart" => $chart
], JSON_UNESCAPED_UNICODE);