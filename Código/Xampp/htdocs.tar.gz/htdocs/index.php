<?php
require_once __DIR__ . "/auth.php";
require_login();
$admin = is_admin();

require_once __DIR__ . "/db.php";

$tipo   = $_GET['tipo'] ?? ($admin ? 'todos' : 'temperatura');
$inicio = $_GET['inicio'] ?? '';
$fim    = $_GET['fim'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SecureRoom</title>
<link rel="stylesheet" href="style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
<div class="glass">

  <div class="topbar">
    <div class="topLeft">
      <h1>Secure Room</h1>
    </div>

    <div class="topCenter">
      <span class="userTag centerUser">
        👤 <?= htmlspecialchars(current_user()['username']) ?> (<?= htmlspecialchars(current_user()['role']) ?>)
      </span>

      <div class="refreshBox centerRefresh">
        <label>Atualizar</label>
        <select id="refresh">
          <option value="2000">2s</option>
          <option value="5000" selected>5s</option>
          <option value="10000">10s</option>
        </select>
        <span class="dot" id="liveDot"></span>
      </div>
    </div>

    <div class="topRight">
      <?php if ($admin): ?>
        <a class="chartsBtn" href="graficos.php">Gráficos</a>
        <a class="forecastBtn" href="forecast.php">Forecast</a>
        <a class="adminBtn" href="admin_users.php">Admin</a>
        <a class="exportBtn" href="export_csv.php?tipo=todos">CSV</a>
      <?php endif; ?>
      <a class="logoutBtn" href="logout.php">Sair</a>
    </div>
  </div>

  <!-- Filtros -->
  <form class="filtros" id="filtros" method="GET">
    <select name="tipo" id="tipo">
      <?php if ($admin): ?>
        <option value="todos" <?= ($tipo === 'todos' ? 'selected' : '') ?>>Todos</option>
      <?php endif; ?>

      <option value="temperatura" <?= ($tipo === 'temperatura' ? 'selected' : '') ?>>Temperatura</option>
      <option value="humidade" <?= ($tipo === 'humidade' ? 'selected' : '') ?>>Humidade</option>

      <?php if ($admin): ?>
        <option value="movimento" <?= ($tipo === 'movimento' ? 'selected' : '') ?>>Movimento</option>
      <?php endif; ?>
    </select>

    <?php if ($admin): ?>
      <input type="date" name="inicio" id="inicio" value="<?= htmlspecialchars($inicio) ?>">
      <input type="date" name="fim" id="fim" value="<?= htmlspecialchars($fim) ?>">
    <?php else: ?>
      <input type="hidden" name="inicio" id="inicio" value="">
      <input type="hidden" name="fim" id="fim" value="">
    <?php endif; ?>

    <button type="submit">Filtrar</button>
  </form>

  <?php if (!$admin): ?>
    <div class="hint24h">Acesso só às últimas 24 horas</div>
  <?php endif; ?>

  <!-- Alertas -->
  <div id="alerta" class="alerta" style="display:none;"></div>

  <!-- Cards -->
  <div class="cards" id="cards">
    <div class="card">
      <div class="cardTitle">Temperatura</div>
      <div class="cardValue" id="cardTemp">—</div>
      <div class="cardMeta" id="cardTempMeta">—</div>
    </div>

    <div class="card">
      <div class="cardTitle">Humidade</div>
      <div class="cardValue" id="cardHum">—</div>
      <div class="cardMeta" id="cardHumMeta">—</div>
    </div>

    <div class="card">
      <div class="cardTitle">Último movimento</div>
      <div class="cardValue"><span class="badge neutral" id="cardMov">—</span></div>
      <div class="cardMeta" id="cardMovMeta">—</div>
    </div>

    <div class="card">
      <div class="cardTitle">RFID (estado)</div>
      <div class="cardValue"><span class="badge neutral" id="cardRfid">—</span></div>
      <div class="cardMeta" id="cardRfidMeta">—</div>
    </div>
  </div>

  <!-- Tabela -->
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Tipo</th>
        <th>Estado / Valor</th>
        <th>Data</th>
      </tr>
    </thead>
    <tbody id="tbody">
      <tr><td colspan="4">A carregar…</td></tr>
    </tbody>
  </table>

  <?php if ($admin): ?>
    <div class="pager">
      <button type="button" id="prevBtn">◀ Anterior</button>

      <div class="pagerInfo" id="pagerInfo">Página —</div>

      <div class="pagerJump">
        <label for="pageInput">Ir para</label>
        <input type="number" id="pageInput" min="1" value="1">
        <button type="button" id="goBtn">Ir</button>
      </div>

      <button type="button" id="nextBtn">Seguinte ▶</button>
    </div>
  <?php endif; ?>


  <h2 id="chartTitle">Gráfico</h2>
  <canvas id="grafico"></canvas>

</div>

<script>
const IS_ADMIN = <?= $admin ? 'true' : 'false' ?>;

let chartInstance = null;
let timer = null;

function qs(id){ return document.getElementById(id); }

function getPageFromUrl(){
  const p = parseInt(new URLSearchParams(location.search).get('page') || '1', 10);
  return isNaN(p) || p < 1 ? 1 : p;
}
let currentPage = IS_ADMIN ? getPageFromUrl() : 1;

function currentParams() {
  return {
    tipo: qs('tipo').value,
    inicio: qs('inicio').value,
    fim: qs('fim').value
  };
}

function setDot(active) {
  qs('liveDot').classList.toggle('on', !!active);
}

function badgeClass(b) {
  if (b === 'ok') return 'ok';
  if (b === 'bad') return 'bad';
  if (b === 'warn') return 'warn';
  return 'neutral';
}

function formatTipo(t) {
  return t.charAt(0).toUpperCase() + t.slice(1);
}

function updateCards(data) {
  const c = data.cards;

  if (c.temp) {
    qs('cardTemp').textContent = `${c.temp.valor} ºC`;
    qs('cardTempMeta').textContent = c.temp.data_hora;
  } else {
    qs('cardTemp').textContent = '—';
    qs('cardTempMeta').textContent = '—';
  }

  if (c.hum) {
    qs('cardHum').textContent = `${c.hum.valor} %`;
    qs('cardHumMeta').textContent = c.hum.data_hora;
  } else {
    qs('cardHum').textContent = '—';
    qs('cardHumMeta').textContent = '—';
  }

  const movBadge = qs('cardMov');
  movBadge.className = `badge ${badgeClass(c.mov.badge)}`;
  movBadge.textContent = c.mov.label;
  qs('cardMovMeta').textContent = c.mov.data_hora || '—';

  const rfidBadge = qs('cardRfid');
  rfidBadge.className = `badge ${badgeClass(c.rfid.badge)}`;
  rfidBadge.textContent = c.rfid.label;
  qs('cardRfidMeta').textContent =
    c.rfid.data_hora
      ? `${c.rfid.data_hora}${c.rfid.uid ? ' • UID: ' + c.rfid.uid : ''}`
      : '—';
}

function updateAlert(data) {
  const el = qs('alerta');
  const alerts = data.alerts || [];

  if (alerts.length) {
    el.style.display = 'block';
    el.innerHTML = alerts.map(a => `<div>${a}</div>`).join('');
  } else {
    el.style.display = 'none';
    el.innerHTML = '';
  }
}

function updateTable(data) {
  const tb = qs('tbody');
  if (!data.rows || data.rows.length === 0) {
    tb.innerHTML = `<tr><td colspan="4">Sem dados</td></tr>`;
    return;
  }

  tb.innerHTML = data.rows.map(r => {
    const badge = badgeClass(r.badge);
    const valor = (r.tipo === 'movimento')
      ? `<span class="badge ${badge}">${r.valorDisplay}</span>`
      : r.valorDisplay;

    return `
      <tr>
        <td>${r.id}</td>
        <td>${formatTipo(r.tipo)}</td>
        <td>${valor}</td>
        <td>${r.data_hora}</td>
      </tr>
    `;
  }).join('');
}

function chartTitleFor(type) {
  if (type === 'temperatura') return 'Temperatura (últimos registos)';
  if (type === 'humidade') return 'Humidade (últimos registos)';
  if (type === 'movimento') return 'Movimento (autorizado vs não autorizado)';
  return 'Gráfico';
}

/* Plugin: valor em cima de cada barra (apenas bar) */
const valueLabelPlugin = {
  id: 'valueLabel',
  afterDatasetsDraw(chart) {
    if (chart.config.type !== 'bar') return;

    const { ctx } = chart;
    ctx.save();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 12px Segoe UI";
    ctx.textAlign = "center";

    chart.data.datasets.forEach((dataset, i) => {
      const meta = chart.getDatasetMeta(i);
      if (meta.hidden) return;

      meta.data.forEach((bar, index) => {
        const value = dataset.data[index];
        if (value === null || value === undefined) return;
        ctx.fillText(value, bar.x, bar.y - 8);
      });
    });

    ctx.restore();
  }
};

function updateChart(chart) {
  const ctx = document.getElementById('grafico');
  const type = chart.type;
  qs('chartTitle').textContent = chartTitleFor(type);

  const desiredType = (type === 'movimento') ? 'scatter' : 'bar';
  const needRecreate = !chartInstance || chartInstance.config.type !== desiredType;

  if (needRecreate && chartInstance) {
    chartInstance.destroy();
    chartInstance = null;
  }

  // Movimento em gráfico scatter
  if (type === 'movimento') {
    const labels = chart.labels;

    const toPoints = (arr, yValue) => {
      const pts = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] === null || typeof arr[i] === 'undefined') continue;
        const jitter = (Math.random() - 0.5) * 0.06;
        pts.push({ x: labels[i], y: yValue + jitter });
      }
      return pts;
    };

    const authPoints   = toPoints(chart.series[0]?.data || [], 1);
    const noAuthPoints = toPoints(chart.series[1]?.data || [], 0);

    const config = {
      type: 'scatter',
      data: {
        datasets: [
          {
            label: 'Movimento autorizado',
            data: authPoints,
            pointRadius: 5,
            pointHoverRadius: 7,
            showLine: false,
            borderColor: '#00f7ff',
            backgroundColor: '#00f7ff'
          },
          {
            label: 'Movimento NÃO autorizado',
            data: noAuthPoints,
            pointRadius: 5,
            pointHoverRadius: 7,
            showLine: false,
            borderColor: '#ff4d6d',
            backgroundColor: '#ff4d6d'
          }
        ]
      },
      options: {
        plugins: {
          legend: { labels: { color: '#ffffff', font: { size: 14 } } },
          tooltip: {
            callbacks: {
              label: (ctx) => (ctx.raw.y > 0.5 ? 'Autorizado ✅' : 'Não autorizado 🚨'),
              title: (items) => items?.[0]?.raw?.x || ''
            }
          }
        },
        scales: {
          x: {
            type: 'category',
            ticks: { color: '#ffffff', maxRotation: 45, minRotation: 45 },
            grid: { color: 'rgba(255,255,255,0.10)' }
          },
          y: {
            min: -0.2,
            max: 1.2,
            ticks: {
              color: '#ffffff',
              stepSize: 1,
              callback: (v) => (v >= 0.5 ? 'Autorizado' : 'Não autorizado')
            },
            grid: { color: 'rgba(255,255,255,0.10)' }
          }
        }
      }
    };

    chartInstance = new Chart(ctx, config);
    return;
  }

  // Temperatura / Humidade
  const datasets = chart.series.map((s) => ({
    label: s.label,
    data: s.data,
    borderWidth: 0,
    borderRadius: 10,
    borderSkipped: false,
    backgroundColor: 'rgba(0,247,255,0.45)',
    hoverBackgroundColor: 'rgba(0,247,255,0.75)'
  }));

  const all = (chart.series?.[0]?.data || []).filter(v => v !== null && typeof v !== 'undefined');
  let minV = all.length ? Math.min(...all) : 0;
  let maxV = all.length ? Math.max(...all) : 10;

  minV = Math.floor(minV) - 1;
  maxV = Math.ceil(maxV) + 1;

  const step = (type === 'humidade') ? 10 : 1;
  if (type === 'humidade') { minV = 30; maxV = 75; }

  const config = {
    type: 'bar',
    data: { labels: chart.labels, datasets },
    plugins: [valueLabelPlugin],
    options: {
      plugins: {
        legend: { labels: { color: '#ffffff', font: { size: 14 } } }
      },
      scales: {
        x: {
          ticks: { color: '#ffffff' },
          grid: { color: 'rgba(255,255,255,0.08)' }
        },
        y: {
          min: minV,
          max: maxV,
          ticks: { color: '#ffffff', stepSize: step },
          grid: { color: 'rgba(255,255,255,0.08)' }
        }
      }
    }
  };

  if (!chartInstance) {
    chartInstance = new Chart(ctx, config);
    return;
  }

  chartInstance.data.labels = chart.labels;
  chartInstance.data.datasets = datasets;
  chartInstance.options.scales.y.min = minV;
  chartInstance.options.scales.y.max = maxV;
  chartInstance.options.scales.y.ticks.stepSize = step;

  chartInstance.update();
}

function updatePager(p) {
  if (!IS_ADMIN || !p) return;

  const info = document.getElementById('pagerInfo');
  const prev = document.getElementById('prevBtn');
  const next = document.getElementById('nextBtn');
  const pageInput = document.getElementById('pageInput');

  if (info) info.textContent = `Página ${p.page} de ${p.totalPages} • Total: ${p.total}`;
  if (prev) prev.disabled = !p.hasPrev;
  if (next) next.disabled = !p.hasNext;

  if (pageInput) {
    pageInput.max = p.totalPages || 1;
    pageInput.value = p.page;
  }
}


async function loadOnce() {
  const {tipo, inicio, fim} = currentParams();

  const url = `api/data.php?tipo=${encodeURIComponent(tipo)}&inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}&limit=50&chartLimit=25&page=${currentPage}`;

  try {
    setDot(true);
    const res = await fetch(url, { cache: 'no-store' });
    const data = await res.json();

    updateCards(data);
    updateAlert(data);
    updateTable(data);
    updateChart(data.chart);
    updatePager(data.pagination);

  } catch (e) {
    console.error(e);
  } finally {
    setDot(false);
  }
}

function startTimer() {
  if (timer) clearInterval(timer);
  const ms = parseInt(qs('refresh').value, 10);
  timer = setInterval(loadOnce, ms);
}

qs('refresh').addEventListener('change', startTimer);

qs('filtros').addEventListener('submit', (ev) => {
  ev.preventDefault();
  const {tipo, inicio, fim} = currentParams();
  currentPage = 1;
  const newUrl = `?tipo=${encodeURIComponent(tipo)}&inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}&page=${currentPage}`;
  history.replaceState(null, '', newUrl);
  loadOnce();
});

if (IS_ADMIN) {
  document.getElementById('prevBtn')?.addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      loadOnce();
    }
  });

  document.getElementById('nextBtn')?.addEventListener('click', () => {
    currentPage++;
    loadOnce();
});

document.getElementById('goBtn')?.addEventListener('click', () => {
  const inp = document.getElementById('pageInput');
  let p = parseInt(inp.value || '1', 10);
  if (isNaN(p) || p < 1) p = 1;

  const maxP = parseInt(inp.max || '1', 10);
  if (!isNaN(maxP) && p > maxP) p = maxP;

  currentPage = p;

  const {tipo, inicio, fim} = currentParams();
  const newUrl = `?tipo=${encodeURIComponent(tipo)}&inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}&page=${currentPage}`;
  history.replaceState(null, '', newUrl);

  loadOnce();
});

// Enter no input também funciona
document.getElementById('pageInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    document.getElementById('goBtn')?.click();
  }
});

}

loadOnce();
startTimer();
</script>
</body>
</html>