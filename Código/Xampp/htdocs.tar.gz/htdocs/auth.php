<?php
// Inicia a sessão apenas se ainda não estiver uma ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verifica se existe um utilizador autenticado na sessão
function is_logged_in(): bool {
    return isset($_SESSION['user']);
}

// Garante que o utilizador está autenticado
// Caso contrário, redireciona para a página de login
function require_login(): void {
    if (!is_logged_in()) {
        header("Location: login.php");
        exit;
    }
}

// Retorna os dados do utilizador atual ou null se não estiver autenticado
function current_user() {
    return $_SESSION['user'] ?? null;
}

// Verifica se o utilizador autenticado tem papel de administrador
function is_admin(): bool {
    $u = current_user();
    return $u && ($u['role'] ?? '') === 'admin';
}

// Garante que o utilizador está autenticado e é administrador
// Caso contrário, retorna erro 403 acesso proibido!
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        echo "Acesso negado.";
        exit;
    }
}
