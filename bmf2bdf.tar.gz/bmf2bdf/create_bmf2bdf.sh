gcc bmf2bdf.c -o bmf2bdf.exe


