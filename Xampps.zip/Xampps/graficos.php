<?php
include "auth.php";
require_admin();
include "db.php";

// --- Temperatura ultimos 30 para se ver bem o gráfico
$tempQ = $conn->query("
  SELECT data_hora, valor
  FROM sensores
  WHERE tipo='temperatura'
  ORDER BY data_hora DESC
  LIMIT 30
");

$tempLabels = [];
$tempVals = [];
if ($tempQ) {
  while ($r = $tempQ->fetch_assoc()) {
    $tempLabels[] = $r['data_hora'];
    $tempVals[] = (float)$r['valor'];
  }
}
$tempLabels = array_reverse($tempLabels);
$tempVals = array_reverse($tempVals);

$tempAvg = null;
$tempAvgQ = $conn->query("
  SELECT AVG(valor) AS avgv
  FROM sensores
  WHERE tipo='temperatura'
  ORDER BY data_hora DESC
  LIMIT 30
");
if ($tempAvgQ && $tempAvgQ->num_rows) {
  $tempAvg = (float)$tempAvgQ->fetch_assoc()['avgv'];
}

// --- Humidade últimos 50
$humQ = $conn->query("
  SELECT data_hora, valor
  FROM sensores
  WHERE tipo='humidade'
  ORDER BY data_hora DESC
  LIMIT 50
");

$humLabels = [];
$humVals = [];
if ($humQ) {
  while ($r = $humQ->fetch_assoc()) {
    $humLabels[] = $r['data_hora'];
    $humVals[] = (float)$r['valor'];
  }
}
$humLabels = array_reverse($humLabels);
$humVals = array_reverse($humVals);

$humAvg = null;
$humAvgQ = $conn->query("
  SELECT AVG(valor) AS avgv
  FROM sensores
  WHERE tipo='humidade'
  ORDER BY data_hora DESC
  LIMIT 50
");
if ($humAvgQ && $humAvgQ->num_rows) {
  $humAvg = (float)$humAvgQ->fetch_assoc()['avgv'];
}

// --- Movimentos por dia dos últimos 30 dias
$movQ = $conn->query("
  SELECT DATE(data_hora) AS dia, COUNT(*) AS total
  FROM sensores
  WHERE tipo='movimento'
    AND data_hora >= (NOW() - INTERVAL 30 DAY)
  GROUP BY DATE(data_hora)
  ORDER BY dia ASC
");

$movDays = [];
$movCounts = [];
$totalMov = 0;
$distinctDays = 0;

if ($movQ) {
  while ($r = $movQ->fetch_assoc()) {
    $movDays[] = $r['dia'];
    $movCounts[] = (int)$r['total'];
    $totalMov += (int)$r['total'];
    $distinctDays++;
  }
}

$movAvgPerDay = null;
if ($distinctDays > 0) {
  $movAvgPerDay = $totalMov / $distinctDays;
}

?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Secure Room — Gráficos</title>
<link rel="stylesheet" href="style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>

.chartsWrap{max-width:980px;margin:0 auto;}
.chartCard{
  margin-top: 16px;
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 18px;
  padding: 16px;
  backdrop-filter: blur(18px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.25);
}
.chartHead{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:12px;
  margin-bottom: 10px;
}
.chartHead h2{margin:0;font-size:18px;opacity:.9;}
.smallStat{
  padding: 8px 12px;
  border-radius: 999px;
  background: rgba(0,247,255,0.12);
  border: 1px solid rgba(0,247,255,0.24);
  font-weight: 900;
  font-size: 13px;
}
.backRow{display:flex;justify-content:space-between;align-items:center;gap:12px;}
.backRow a{color:#fff;text-decoration:none;opacity:.9;}
</style>
</head>

<body>
<div class="glass chartsWrap">

  <div class="backRow">
    <h1>Gráficos</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a class="chartsBtn" href="index.php">← Voltar</a>
      <a class="logoutBtn" href="logout.php">Sair</a>
    </div>
  </div>

  <!-- Temperatura -->
  <div class="chartCard">
    <div class="chartHead">
      <h2>Temperatura</h2>
      <div class="smallStat">
        Média: <?= $tempAvg !== null ? number_format($tempAvg, 1, '.', '') . " ºC" : "—" ?>
      </div>
    </div>
    <canvas id="chartTemp"></canvas>
  </div>

  <!-- Humidade -->
  <div class="chartCard">
    <div class="chartHead">
      <h2>Humidade</h2>
      <div class="smallStat">
        Média: <?= $humAvg !== null ? number_format($humAvg, 1, '.', '') . " %" : "—" ?>
      </div>
    </div>
    <canvas id="chartHum"></canvas>
  </div>

  <!-- Movimentos por dia -->
  <div class="chartCard">
    <div class="chartHead">
      <h2>Movimentos por dia (últimos 30 dias)</h2>
      <div class="smallStat">
        Média/dia: <?= $movAvgPerDay !== null ? number_format($movAvgPerDay, 1, '.', '') : "—" ?>
      </div>
    </div>
    <canvas id="chartMov"></canvas>
  </div>

</div>

<script>
const valueLabelPlugin = {
  id: 'valueLabel',
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 12px Segoe UI";
    ctx.textAlign = "center";

    chart.data.datasets.forEach((dataset, i) => {
      const meta = chart.getDatasetMeta(i);
      if (meta.hidden) return;

      meta.data.forEach((elem, idx) => {
        const v = dataset.data[idx];
        if (v === null || v === undefined) return;
        ctx.fillText(v, elem.x, elem.y - 8);
      });
    });

    ctx.restore();
  }
};

// Temperatura
new Chart(document.getElementById('chartTemp'), {
  type: 'bar',
  plugins: [valueLabelPlugin],
  data: {
    labels: <?= json_encode($tempLabels, JSON_UNESCAPED_UNICODE) ?>,
    datasets: [{
      label: 'ºC',
      data: <?= json_encode($tempVals) ?>,
      borderRadius: 10,
      borderSkipped: false,
      backgroundColor: 'rgba(0,247,255,0.45)',
      hoverBackgroundColor: 'rgba(0,247,255,0.75)'
    }]
  },
  options: {
    plugins: { legend: { labels: { color: '#fff' } } },
    scales: {
      x: { ticks: { color: '#fff', maxRotation: 45, minRotation: 45 }, grid: { color: 'rgba(255,255,255,0.08)' } },
      y: { min: 0, max: 30, ticks: { color: '#fff', stepSize: 1 }, grid: { color: 'rgba(255,255,255,0.08)' } }

    }
  }
});

// Humidade
new Chart(document.getElementById('chartHum'), {
  type: 'bar',
  plugins: [valueLabelPlugin],
  data: {
    labels: <?= json_encode($humLabels, JSON_UNESCAPED_UNICODE) ?>,
    datasets: [{
      label: '%',
      data: <?= json_encode($humVals) ?>,
      borderRadius: 10,
      borderSkipped: false,
      backgroundColor: 'rgba(0,247,255,0.45)',
      hoverBackgroundColor: 'rgba(0,247,255,0.75)'
    }]
  },
  options: {
    plugins: { legend: { labels: { color: '#fff' } } },
    scales: {
      x: { ticks: { color: '#fff', maxRotation: 45, minRotation: 45 }, grid: { color: 'rgba(255,255,255,0.08)' } },
      y: { min: 30, max: 75, ticks: { color: '#fff', stepSize: 5 }, grid: { color: 'rgba(255,255,255,0.08)' }
      }
    }
  }
});

// Movimentos por dia
new Chart(document.getElementById('chartMov'), {
  type: 'bar',
  plugins: [valueLabelPlugin],
  data: {
    labels: <?= json_encode($movDays, JSON_UNESCAPED_UNICODE) ?>,
    datasets: [{
      label: 'Movimentos/dia',
      data: <?= json_encode($movCounts) ?>,
      borderRadius: 10,
      borderSkipped: false,
      backgroundColor: 'rgba(255,77,109,0.35)',
      hoverBackgroundColor: 'rgba(255,77,109,0.70)'
    }]
  },
  options: {
    plugins: { legend: { labels: { color: '#fff' } } },
    scales: {
      x: { ticks: { color: '#fff', maxRotation: 45, minRotation: 45 }, grid: { color: 'rgba(255,255,255,0.08)' } },
      y: { min: 0, max: 20 , ticks: { color: '#fff', stepSize: 1 }, grid: { color: 'rgba(255,255,255,0.08)' } }
    }
  }
});
</script>
</body>
</html>