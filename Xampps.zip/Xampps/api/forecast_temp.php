<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../auth.php';
require_login();

$isAdmin = (current_user()['role'] ?? 'user') === 'admin';
if (!$isAdmin) {
  http_response_code(403);
  echo json_encode(["ok"=>false,"error"=>"forbidden"], JSON_UNESCAPED_UNICODE);
  exit;
}

/*
  GET:
    h=60 ou 180 (minutos)
    n=quantos pontos de histórico devolver (default 120)
*/

$h = isset($_GET['h']) ? (int)$_GET['h'] : 60;
$h = ($h === 180) ? 180 : 60;

$n = isset($_GET['n']) ? (int)$_GET['n'] : 120;
$n = max(30, min($n, 400));

$py = escapeshellcmd("python");
$script = escapeshellarg(__DIR__ . "/../ai/forecast_temp.py");

$hArg = escapeshellarg((string)$h);
$nArg = escapeshellarg((string)$n);

// junta stderr ao stdout para apanhar warnings também
$cmd = "$py $script $hArg $nArg 2>&1";
$out = shell_exec($cmd);

if (!$out) {
  echo json_encode(["ok"=>false,"error"=>"python_sem_resposta"], JSON_UNESCAPED_UNICODE);
  exit;
}

// extrair apenas JSON (primeiro { até último })
$start = strpos($out, '{');
$end = strrpos($out, '}');
if ($start === false || $end === false || $end <= $start) {
  echo json_encode(["ok"=>false,"error"=>"python_sem_json","raw"=>$out], JSON_UNESCAPED_UNICODE);
  exit;
}
$jsonOnly = substr($out, $start, $end - $start + 1);

$pred = json_decode($jsonOnly, true);
if (!is_array($pred) || empty($pred['ok'])) {
  echo json_encode(["ok"=>false,"error"=>"python_json_invalido","raw"=>$jsonOnly], JSON_UNESCAPED_UNICODE);
  exit;
}

// devolve exatamente o que o python manda
echo json_encode($pred, JSON_UNESCAPED_UNICODE);