<?php
include "db.php";
include "auth.php";
require_admin();

$msg = "";
$err = "";

// SUPER ADMIN (não pode ser bloqueado por outros)
$superAdminId = 1;

// utilizador atual
$currentUser = current_user();
$currentUserId = (int)($currentUser['id'] ?? 0);
$isSuperAdmin = ($currentUserId === $superAdminId);

/* =============================
    ADICIONAR / ASSOCIAR CARTÃO
   ============================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_card') {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $uid = strtoupper(trim($_POST['rfid_uid'] ?? ''));

    // limpa espaços e ":" etc
    $uid = preg_replace('/[^0-9A-F]/', '', $uid);

    if ($user_id <= 0 || $uid === '') {
        $err = "Seleciona utilizador e UID válido.";
    } else {
        $stmt = $conn->prepare("INSERT INTO user_cards (user_id, rfid_uid, active) VALUES (?, ?, 1)");
        $stmt->bind_param("is", $user_id, $uid);
        if ($stmt->execute()) $msg = "Cartão associado.";
        else $err = "Erro: " . $conn->error;
    }
}

/* =================================================
   TOGGLE ACTIVE (ATIVAR / DESATIVAR)
   Regras:
   - SuperAdmin pode tudo
   - Admin normal:
       * NÃO pode desativar o próprio cartão
       * NÃO pode desativar cartões do SuperAdmin
       * Pode desativar/ativar cartões dos outros
   ================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle') {
    $id = (int)($_POST['id'] ?? 0);
    $active = (int)($_POST['active'] ?? 0);

    if ($id > 0) {
        // descobrir a quem pertence o cartão
        $stmt = $conn->prepare("SELECT user_id, active FROM user_cards WHERE id=? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $cardRes = $stmt->get_result();
        $card = $cardRes ? $cardRes->fetch_assoc() : null;

        if (!$card) {
            $err = "Cartão não encontrado.";
        } else {
            $cardUserId = (int)$card['user_id'];
            $isActive = (int)$card['active'] === 1;

            $new = $isActive ? 0 : 1;

            if ($new === 0 && !$isSuperAdmin) {

                // 1) Admin normal não pode desativar cartões do SuperAdmin
                if ($cardUserId === $superAdminId) {
                    $err = "Não podes desativar cartões do Admin principal.";
                }
                // 2) Admin normal não pode desativar os próprios cartões
                elseif ($cardUserId === $currentUserId) {
                    $err = "Não podes desativar o teu próprio cartão (segurança).";
                }
            }

            if ($err === "") {
                $upd = $conn->prepare("UPDATE user_cards SET active=? WHERE id=?");
                $upd->bind_param("ii", $new, $id);

                if ($upd->execute()) {
                    $msg = $new ? "Cartão ativado." : "Cartão desativado.";
                } else {
                    $err = "Erro: " . $conn->error;
                }
            }
        }
    }
}

$users = $conn->query("SELECT id, username FROM users ORDER BY username ASC");

// user_id e role para dar permissões na UI
$cards = $conn->query("
  SELECT c.id, c.user_id, c.rfid_uid, c.active, c.created_at, u.username, u.role
  FROM user_cards c
  JOIN users u ON u.id = c.user_id
  ORDER BY c.id DESC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SecureRoom — Admin RFID</title>
<link rel="stylesheet" href="style.css">
<style>
.adminWrap{max-width:1150px;margin:0 auto;}
.adminHeader{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;}
.adminHeader a{color:#fff;text-decoration:none;opacity:.9;}
.panel{
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 18px;
  padding: 16px;
  backdrop-filter: blur(18px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.25);
  margin-bottom: 14px;
}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
.row input,.row select{padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,0.14);background:rgba(0,0,0,0.22);color:#fff;}
.row button{padding:10px 12px;border-radius:12px;border:none;background:linear-gradient(45deg,#00c6ff,#0072ff);color:#fff;font-weight:800;cursor:pointer;}
.notice{padding:10px 12px;border-radius:12px;margin-bottom:12px;font-weight:800;}
.ok{background:rgba(0,247,255,0.12);border:1px solid rgba(0,247,255,0.28);}
.bad{background:rgba(255,77,109,0.12);border:1px solid rgba(255,77,109,0.28);}
.small{opacity:.85;font-size:12px;margin-top:6px;}
.lockTag{display:inline-block;padding:4px 10px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);font-size:12px;}
</style>
</head>
<body>
<div class="adminWrap glass">
  <div class="adminHeader">
    <h1>Admin — RFID</h1>
    <div>
      <a href="index.php">← Voltar ao dashboard</a> ·
      <a href="admin_users.php">Gerir users</a> ·
      <a href="logout.php">Sair</a>
    </div>
  </div>

  <?php if ($msg): ?><div class="notice ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="notice bad"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="panel">
    <h2>Associar cartão a utilizador</h2>
    <form method="POST" class="row">
      <input type="hidden" name="action" value="add_card">
      <select name="user_id" required>
        <option value="">Seleciona utilizador</option>
        <?php while($u = $users->fetch_assoc()): ?>
          <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option>
        <?php endwhile; ?>
      </select>
      <input name="rfid_uid" placeholder="UID (ex: 9B1EF604)" required>
      <button type="submit">Associar</button>
    </form>
    <div class="small">Aceita UID com ":" ou espaços — eu limpo automaticamente.</div>
  </div>

  <div class="panel">
    <h2>Cartões registados</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Utilizador</th><th>UID</th><th>Ativo</th><th>Criado</th><th>Ação</th>
        </tr>
      </thead>
      <tbody>
      <?php while($c = $cards->fetch_assoc()): ?>
        <?php
          $cardId = (int)$c['id'];
          $cardUserId = (int)$c['user_id'];
          $isActive = (int)$c['active'] === 1;

          $isCardSuperAdmin = ($cardUserId === $superAdminId);
          $isOwnCard = ($cardUserId === $currentUserId);

          // regra UI: desativar bloqueado para admin normal quando:
          // - cartão do superadmin
          // - ou é o próprio cartão
          $disableDeactivate = (!$isSuperAdmin && $isActive && ($isCardSuperAdmin || $isOwnCard));

          $why = "";
          if ($disableDeactivate) {
            if ($isCardSuperAdmin) $why = "Admin principal protegido";
            else $why = "Não podes desativar o teu cartão";
          }
        ?>
        <tr>
          <td><?= $cardId ?></td>
          <td>
            <?= htmlspecialchars($c['username']) ?>
            <?php if ($isCardSuperAdmin): ?> <span class="lockTag">Admin principal</span><?php endif; ?>
          </td>
          <td><?= htmlspecialchars($c['rfid_uid']) ?></td>
          <td><?= $isActive ? 'Sim' : 'Não' ?></td>
          <td><?= htmlspecialchars($c['created_at']) ?></td>
          <td>
            <form method="POST" class="row" style="justify-content:center;">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $cardId ?>">
              <input type="hidden" name="active" value="<?= (int)$c['active'] ?>">

              <?php if ($isActive): ?>
                <button type="submit" <?= $disableDeactivate ? 'disabled style="opacity:.5;cursor:not-allowed;"' : '' ?>>
                  Desativar
                </button>
                <?php if ($disableDeactivate): ?>
                  <span class="small">🔒 <?= htmlspecialchars($why) ?></span>
                <?php endif; ?>
              <?php else: ?>
                <button type="submit">Ativar</button>
              <?php endif; ?>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>

</div>
</body>
</html>